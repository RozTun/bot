from kyt import *

@bot.on(events.CallbackQuery(data=b'restore77'))
async def create_restore(event):
	async def create_restore_(event):
		async with bot.conversation(chat) as pw2:
			await event.respond("**» LINK BACKUP :**")
			pw2 = pw2.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pw2 = (await pw2).raw_text
		cmd = f'printf "%s\n" "1" "{pw2}" | m-backup | sleep 15 | exit'
		subprocess.check_output(cmd, shell=True)
		await event.respond(f"""
**» SUCCES RESTORE AKUN**
**» DONE**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await create_restore_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'backup77'))
async def backup(event):
	async def backup_(event):
		cmd = f'printf "%s\n" "3" | m-backup | sleep 6 | exit'
		time.sleep(0)
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)		
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 100%\n█████████████████████████ `")
		await event.edit(f"""
**» Succes**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await backup_(event)
	else:
		await event.answer("Access Denied",alert=True)
		
@bot.on(events.CallbackQuery(data=b'reboot77'))
async def rebooot(event):
	async def rebooot_(event):
		cmd = f'shutdown -r now'
		await event.edit("Processing.")
		await event.edit("Processing..")
		await event.edit("Processing...")
		await event.edit("Processing....")
		time.sleep(1)
		await event.edit("`Processing Restart Service Server...`")
		time.sleep(1)
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 100%\n█████████████████████████ `")
		await event.edit(f"""
**» REBOOT SERVER**
**» DONE**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
		subprocess.check_output(cmd, shell=True)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await rebooot_(event)
	else:
		await event.answer("Access Denied",alert=True)

@bot.on(events.CallbackQuery(data=b'speedtest77'))
async def speedtest(event):
	async def speedtest_(event):
		cmd = 'speedtest-cli --share'.strip()
		time.sleep(0)
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 100%\n█████████████████████████ `")
		await event.edit(f"""
**
{z}
**
**» Succes**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await speedtest_(event)
	else:
		await event.answer("Access Denied",alert=True)

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
	inline = [
[Button.inline(" MENU SSH ","ssh"),
Button.inline(" MENU VMESS ","vmess")],
[Button.inline(" MENU VLESS ","vless"),
Button.inline(" MENU TROJAN ","trojan")],
[Button.inline(" MENU SETTING ","setting")]]
	sender = await event.get_sender()
	val = valid(str(sender.id))
	if val == "false":
		try:
			await event.answer("Buy Premium Chat @rmblvpn1", alert=True)
		except:
			await event.reply("Buy Premium Chat @Rmblvpn1")
	elif val == "true":
		sh = f' cat /etc/xray/ssh | grep "###" | wc -l'
		ssh = subprocess.check_output(sh, shell=True).decode("ascii")
		vm = f' cat /etc/xray/config.json | grep "#vmg" | wc -l'
		vms = subprocess.check_output(vm, shell=True).decode("ascii")
		vl = f' cat /etc/xray/config.json | grep "#vlg" | wc -l'
		vls = subprocess.check_output(vl, shell=True).decode("ascii")
		tr = f' cat /etc/xray/config.json | grep "#trg" | wc -l'
		trj = subprocess.check_output(tr, shell=True).decode("ascii")
		sdss = f" cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'"
		namaos = subprocess.check_output(sdss, shell=True).decode("ascii")
		ipvps = f" curl -s ipv4.icanhazip.com"
		ipsaya = subprocess.check_output(ipvps, shell=True).decode("ascii")
		citsy = f" cat /etc/xray/city"
		city = subprocess.check_output(citsy, shell=True).decode("ascii")
		bant = f" cat /etc/usage2"
		bantwidth = subprocess.check_output(bant, shell=True).decode("ascii")
		sc2 = f" cat /etc/scdurasi"
		sc = subprocess.check_output(sc2, shell=True).decode("ascii")
		ispy = f" cat /etc/xray/isp"
		isp = subprocess.check_output(ispy, shell=True).decode("ascii")
		ngx = subprocess.call(["systemctl", "is-active", "--quiet", "nginx"])
		if(ngx == 0):
			ngx1 = f'🟢 [ON]'
		else:
			ngx1 = f'🔴 [OFF]'
		xr = subprocess.call(["systemctl", "is-active", "--quiet", "xray"])
		if(xr == 0):
			xr1 = f'🟢 [ON]'
		else:
			xr1 - f'🔴 [OFF]'
		sh = subprocess.call(["systemctl", "is-active", "--quiet", "ws-stunnel"])
		if(sh == 0):
			ws1 = f'🟢 [ON]'
		else:
			ws1 = f'🔴 [OFF]'
		msg = f"""
✧◇───────────────────◇✧ 
      **💥⟨ 𝗕𝗼𝘁 𝗥𝗺𝗯𝗹 𝗩𝗽𝗻 𝗧𝘂𝗻𝗻𝗲𝗹 ⟩💥**
✧◇───────────────────◇✧
**» ♦IP VPS :** `{ipsaya.strip()}`
**» ♦CITY   :** `{city.strip()}`
**» ♦DOMAIN :** `{DOMAIN}`
**» ♦Total Bantwidth :** `{bantwidth.strip()}`
**» ♦Durasi Aktif :** `{sc.strip()}`
✧◇───────────────────◇✧
             **💥» Status Service:💥**
✧◇───────────────────◇✧
**» ♦ NGINX  :**  `{ngx1}`
**» ♦ XRAY   :**  `{xr1}`
**» ♦ SSH   :**  `{ws1}`
✧◇───────────────────◇✧
            **💥⟨ 𝗧𝗼𝘁𝗮𝗹 𝘼𝙘𝙘𝙤𝙪𝙣𝙩 ⟩💥**
✧◇───────────────────◇✧
**» ♦SSH OVPN    :** `{ssh.strip()}` __account__
**» ♦XRAY VMESS  :** `{vms.strip()}` __account__
**» ♦XRAY VLESS  :** `{vls.strip()}` __account__
**» ♦XRAY TROJAN :** `{trj.strip()}` __account__
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
		x = await event.edit(msg,buttons=inline)
		if not x:
			await event.reply(msg,buttons=inline)
